## instructions

in cmd prompt, execute the following to setup environment
```
npm install
```

to host the app locally on port 3000, execute the following
```
npm run dev
```